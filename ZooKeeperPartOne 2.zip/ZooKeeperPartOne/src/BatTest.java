
public class BatTest {

	public static void main(String[] args) {
		Bat b = new Bat();
		b.attackTown();
		b.eatLotsOfHumans();
		b.attackTown();
		b.eatHumans();
		b.eatHumans();
		b.attackTown();
		b.fly();
		b.fly();
		b.displayEnergy();

	}

}
