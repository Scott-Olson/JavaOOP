public class ProjectClass{
	private String name;
	private String description;
	
	public void Project(){
		this.name = "Default project name";
		this.description = "A new project waiting to be updated";
	}
	public void Project(String name){
		this.name = name;
	}
	public  void Project(String name, String description){
		this.name = name;
		this.description = description;
	}
	//getters
	public String getName(){
		return name;
	}
	public String getDesc(){
		return description;
	}
	//setters
	public void setName(String name){
		this.name = name;
	}
	public void setDesc(String description){
		this.description = description;
	}



	public void elevatorPitch(){
		System.out.println(this.getName() + " : " + this.getDesc());
	}
}